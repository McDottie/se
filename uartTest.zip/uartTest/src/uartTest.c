/*
===============================================================================
 Name        : uartTest.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>

#include <stdio.h>
#include <stdlib.h>
#include "uart.h"
#include "wait.h"

int main(void) {
	WAIT_Init();
	int dlen = sizeof("Hello World. A very very long hello world\n");
	UART_Initialize(115200, UART2);
	char * data = malloc(dlen);
	while (1) {
		memset(data, 0, dlen);
		UART_WriteBuffer("Hello World. A very very long hello world\n",dlen);
		UART_ReadBuffer(data, dlen);
		printf("%s", data);
	 }
	 return 0 ;
}
