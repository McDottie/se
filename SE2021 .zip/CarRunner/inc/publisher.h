/*
 * publisher.h
 *
 *  Created on: 28/06/2021
 *      Author: josee
 */

#ifndef PUBLISHER_H_
#define PUBLISHER_H_

void PUBLISHER_Publish(int group, int score, char * username);

#endif /* PUBLISHER_H_ */
