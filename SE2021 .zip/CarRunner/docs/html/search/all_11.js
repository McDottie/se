var searchData=
[
  ['s_192',['S',['../db/dc4/group__BUTTONS.html#gaf933676109efed7ab34cea71d748a517',1,'CarRunner.h']]],
  ['saver_2ec_193',['saver.c',['../d1/dee/saver_8c.html',1,'']]],
  ['saver_2eh_194',['saver.h',['../d5/d04/saver_8h.html',1,'']]],
  ['savescore_195',['saveScore',['../d5/d04/saver_8h.html#a80a44e8469613fd1a9b7078f5f012bd1',1,'saveScore(int score, char *name, int name_size):&#160;saver.c'],['../d1/dee/saver_8c.html#a80a44e8469613fd1a9b7078f5f012bd1',1,'saveScore(int score, char *name, int name_size):&#160;saver.c']]],
  ['saveuser_196',['saveUser',['../d1/dcb/game_8c.html#ae2a3552aec8bec9021c1063049400e3b',1,'game.c']]],
  ['scores_197',['scores',['../d1/dee/saver_8c.html#a859dd84beee150c7f6f6e683f1dc91ac',1,'saver.c']]],
  ['sector28_198',['sector28',['../da/da8/Flash_8h.html#a717fc8cb2c79e2cdae13b7e9e3a7ccbd',1,'Flash.h']]],
  ['sector29_199',['sector29',['../da/da8/Flash_8h.html#a325e91919e6e0b98e77f6c129446de9e',1,'Flash.h']]],
  ['sector_5fsize_200',['SECTOR_SIZE',['../da/da8/Flash_8h.html#aa35bad1e92008da628f27b2f6bb270aa',1,'Flash.h']]],
  ['setuptap_201',['setupTap',['../de/dfe/ADXL345_8h.html#a6a554e6ac4d26bac4b26dd8a4d0a45f8',1,'setupTap(float threshold, float duration, float latency, float window):&#160;ADXL345.c'],['../d4/ddb/ADXL345_8c.html#a6a554e6ac4d26bac4b26dd8a4d0a45f8',1,'setupTap(float threshold, float duration, float latency, float window):&#160;ADXL345.c']]],
  ['spi_2ec_202',['spi.c',['../da/d00/spi_8c.html',1,'']]],
  ['spi_2eh_203',['spi.h',['../da/d87/spi_8h.html',1,'']]],
  ['spi_5fconfigtransfer_204',['SPI_ConfigTransfer',['../da/d87/spi_8h.html#afdfd38280ebbf6be99ed3540c0678313',1,'SPI_ConfigTransfer(int frequency, int bitData, int mode):&#160;spi.c'],['../da/d00/spi_8c.html#afdfd38280ebbf6be99ed3540c0678313',1,'SPI_ConfigTransfer(int frequency, int bitData, int mode):&#160;spi.c']]],
  ['spi_5finit_205',['SPI_Init',['../da/d87/spi_8h.html#a292196e767158c66f03cbcc244fc802b',1,'SPI_Init(void):&#160;spi.c'],['../da/d00/spi_8c.html#a292196e767158c66f03cbcc244fc802b',1,'SPI_Init(void):&#160;spi.c']]],
  ['spi_5ftransfer_206',['SPI_Transfer',['../da/d87/spi_8h.html#adf7db1666629f8a6c11d0be20e592940',1,'SPI_Transfer(unsigned short *txBuffer, unsigned short *rxBuffer, int lenght):&#160;spi.c'],['../da/d00/spi_8c.html#adf7db1666629f8a6c11d0be20e592940',1,'SPI_Transfer(unsigned short *txBuffer, unsigned short *rxBuffer, int lenght):&#160;spi.c']]],
  ['state_207',['state',['../dc/d68/structkey__state.html#a42be32cf0cb8d287f43befbbb6715472',1,'key_state']]],
  ['svc_5fhandler_208',['SVC_Handler',['../df/d04/cr__startup__lpc175x__6x_8c.html#a553d3c6fbc0ff764fa70b866b5c79e3e',1,'cr_startup_lpc175x_6x.c']]],
  ['systick_5ffreq_209',['SYSTICK_FREQ',['../dd/d10/wait_8c.html#a259bee748117476f5bf763c71a2f66a8',1,'wait.c']]],
  ['systick_5fhandler_210',['SysTick_Handler',['../df/d04/cr__startup__lpc175x__6x_8c.html#ab80f32111a0725c9f4cdfb9d6c9b7f82',1,'SysTick_Handler(void):&#160;wait.c'],['../dd/d10/wait_8c.html#ab5e09814056d617c521549e542639b7e',1,'SysTick_Handler(void):&#160;wait.c']]]
];
