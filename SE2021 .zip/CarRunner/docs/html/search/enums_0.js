var searchData=
[
  ['adx345_5fdatarate_5ft_358',['ADX345_DataRate_t',['../de/dfe/ADXL345_8h.html#a4b57ccec449cacb2e7d1aa89e6416355',1,'ADXL345.h']]],
  ['adx345_5frange_5ft_359',['ADX345_Range_t',['../de/dfe/ADXL345_8h.html#a5ea6ae5aace0e199d7bcf6ba2c106fe4',1,'ADXL345.h']]]
];
