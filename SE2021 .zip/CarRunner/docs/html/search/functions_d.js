var searchData=
[
  ['readnames_306',['readNames',['../d5/d04/saver_8h.html#a66bcbb74da6580309611caac3a022592',1,'readNames(char *strings[]):&#160;saver.c'],['../d1/dee/saver_8c.html#a66bcbb74da6580309611caac3a022592',1,'readNames(char *strings[]):&#160;saver.c']]],
  ['readregister_307',['readRegister',['../d4/ddb/ADXL345_8c.html#a0e11c845302c3c61651b273be2fd0cf9',1,'ADXL345.c']]],
  ['readregisters_308',['readRegisters',['../d4/ddb/ADXL345_8c.html#a928ab41b39807da5e3cb8f495e99586c',1,'ADXL345.c']]],
  ['readscores_309',['readScores',['../d5/d04/saver_8h.html#a2970ebb257cd1fd2595b817dd35fe21b',1,'readScores():&#160;saver.c'],['../d1/dee/saver_8c.html#a2970ebb257cd1fd2595b817dd35fe21b',1,'readScores():&#160;saver.c']]],
  ['resetisr_310',['ResetISR',['../df/d04/cr__startup__lpc175x__6x_8c.html#a516ff8924be921fa3a1bb7754b1f5734',1,'cr_startup_lpc175x_6x.c']]],
  ['routinechooser_311',['routineChooser',['../de/d08/CarRunner_8c.html#a18e3ef9037a022b853f82460dc9fb422',1,'CarRunner.c']]],
  ['rtc_5fgetseconds_312',['RTC_GetSeconds',['../dc/d1b/rtc_8h.html#aed5e5912abe16282e6934f5c108f4ca9',1,'RTC_GetSeconds(void):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#aed5e5912abe16282e6934f5c108f4ca9',1,'RTC_GetSeconds(void):&#160;rtc.c']]],
  ['rtc_5fgetvalue_313',['RTC_GetValue',['../dc/d1b/rtc_8h.html#a506e5d1d8d538575e4739d85f4db7ff1',1,'RTC_GetValue(struct tm *dateTime):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#a506e5d1d8d538575e4739d85f4db7ff1',1,'RTC_GetValue(struct tm *dateTime):&#160;rtc.c']]],
  ['rtc_5finit_314',['RTC_Init',['../dc/d1b/rtc_8h.html#a8ce39fc6eece59a57c6343c3ee52cbf5',1,'RTC_Init(time_t seconds):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#a8ce39fc6eece59a57c6343c3ee52cbf5',1,'RTC_Init(time_t seconds):&#160;rtc.c']]],
  ['rtc_5fsetseconds_315',['RTC_SetSeconds',['../dc/d1b/rtc_8h.html#acefa177b35b24cdd98a156950f7d051b',1,'RTC_SetSeconds(time_t seconds):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#acefa177b35b24cdd98a156950f7d051b',1,'RTC_SetSeconds(time_t seconds):&#160;rtc.c']]],
  ['rtc_5fsetvalue_316',['RTC_SetValue',['../dc/d1b/rtc_8h.html#a14fa105430d9febf19fe275cee4664d8',1,'RTC_SetValue(struct tm *dateTime):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#a14fa105430d9febf19fe275cee4664d8',1,'RTC_SetValue(struct tm *dateTime):&#160;rtc.c']]]
];
