var searchData=
[
  ['adxl345_5finit_261',['ADXL345_Init',['../de/dfe/ADXL345_8h.html#a8b534976940f09e90a216c7bcfbf8dd6',1,'ADXL345_Init(void):&#160;ADXL345.c'],['../d4/ddb/ADXL345_8c.html#a8a64ce2969d6f48bc73054688cd07601',1,'ADXL345_Init():&#160;ADXL345.c']]],
  ['adxl345_5fisdoubletap_262',['ADXL345_isDoubleTap',['../de/dfe/ADXL345_8h.html#a3751151b7eba20da7a279cf4ce45d7cb',1,'ADXL345_isDoubleTap():&#160;ADXL345.c'],['../d4/ddb/ADXL345_8c.html#a3751151b7eba20da7a279cf4ce45d7cb',1,'ADXL345_isDoubleTap():&#160;ADXL345.c']]],
  ['adxl345_5fistap_263',['ADXL345_isTap',['../de/dfe/ADXL345_8h.html#aae8e9036157ce6d4564f064f0695ee51',1,'ADXL345_isTap():&#160;ADXL345.c'],['../d4/ddb/ADXL345_8c.html#aae8e9036157ce6d4564f064f0695ee51',1,'ADXL345_isTap():&#160;ADXL345.c']]],
  ['adxl345_5fread_264',['ADXL345_Read',['../de/dfe/ADXL345_8h.html#ae54c23328bc72ec7359eecef4ce2ed83',1,'ADXL345_Read(float *x_value, float *y_value, float *z_value):&#160;ADXL345.c'],['../d4/ddb/ADXL345_8c.html#ae54c23328bc72ec7359eecef4ce2ed83',1,'ADXL345_Read(float *x_value, float *y_value, float *z_value):&#160;ADXL345.c']]]
];
