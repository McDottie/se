var searchData=
[
  ['time_5fchangeroutine_211',['Time_changeRoutine',['../d7/dba/time__helper_8h.html#a3d09c604a329253d63a4053e10edbbba',1,'Time_changeRoutine(time_t seconds):&#160;time_helper.c'],['../d3/d36/time__helper_8c.html#a3d09c604a329253d63a4053e10edbbba',1,'Time_changeRoutine(time_t seconds):&#160;time_helper.c']]],
  ['time_5fhelper_2ec_212',['time_helper.c',['../d3/d36/time__helper_8c.html',1,'']]],
  ['time_5fhelper_2eh_213',['time_helper.h',['../d7/dba/time__helper_8h.html',1,'']]]
];
