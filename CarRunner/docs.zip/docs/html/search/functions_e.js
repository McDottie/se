var searchData=
[
  ['savescore_317',['saveScore',['../d5/d04/saver_8h.html#a80a44e8469613fd1a9b7078f5f012bd1',1,'saveScore(int score, char *name, int name_size):&#160;saver.c'],['../d1/dee/saver_8c.html#a80a44e8469613fd1a9b7078f5f012bd1',1,'saveScore(int score, char *name, int name_size):&#160;saver.c']]],
  ['saveuser_318',['saveUser',['../d1/dcb/game_8c.html#ae2a3552aec8bec9021c1063049400e3b',1,'game.c']]],
  ['setuptap_319',['setupTap',['../de/dfe/ADXL345_8h.html#a6a554e6ac4d26bac4b26dd8a4d0a45f8',1,'setupTap(float threshold, float duration, float latency, float window):&#160;ADXL345.c'],['../d4/ddb/ADXL345_8c.html#a6a554e6ac4d26bac4b26dd8a4d0a45f8',1,'setupTap(float threshold, float duration, float latency, float window):&#160;ADXL345.c']]],
  ['spi_5fconfigtransfer_320',['SPI_ConfigTransfer',['../da/d87/spi_8h.html#afdfd38280ebbf6be99ed3540c0678313',1,'SPI_ConfigTransfer(int frequency, int bitData, int mode):&#160;spi.c'],['../da/d00/spi_8c.html#afdfd38280ebbf6be99ed3540c0678313',1,'SPI_ConfigTransfer(int frequency, int bitData, int mode):&#160;spi.c']]],
  ['spi_5finit_321',['SPI_Init',['../da/d87/spi_8h.html#a292196e767158c66f03cbcc244fc802b',1,'SPI_Init(void):&#160;spi.c'],['../da/d00/spi_8c.html#a292196e767158c66f03cbcc244fc802b',1,'SPI_Init(void):&#160;spi.c']]],
  ['spi_5ftransfer_322',['SPI_Transfer',['../da/d87/spi_8h.html#adf7db1666629f8a6c11d0be20e592940',1,'SPI_Transfer(unsigned short *txBuffer, unsigned short *rxBuffer, int lenght):&#160;spi.c'],['../da/d00/spi_8c.html#adf7db1666629f8a6c11d0be20e592940',1,'SPI_Transfer(unsigned short *txBuffer, unsigned short *rxBuffer, int lenght):&#160;spi.c']]],
  ['svc_5fhandler_323',['SVC_Handler',['../df/d04/cr__startup__lpc175x__6x_8c.html#a553d3c6fbc0ff764fa70b866b5c79e3e',1,'cr_startup_lpc175x_6x.c']]],
  ['systick_5fhandler_324',['SysTick_Handler',['../df/d04/cr__startup__lpc175x__6x_8c.html#ab80f32111a0725c9f4cdfb9d6c9b7f82',1,'SysTick_Handler(void):&#160;wait.c'],['../dd/d10/wait_8c.html#ab5e09814056d617c521549e542639b7e',1,'SysTick_Handler(void):&#160;wait.c']]]
];
