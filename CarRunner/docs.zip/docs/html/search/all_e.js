var searchData=
[
  ['obs_168',['OBS',['../d1/dcb/game_8c.html#a100c68e576715ae019c2ec8e90f342ec',1,'game.c']]]
];
