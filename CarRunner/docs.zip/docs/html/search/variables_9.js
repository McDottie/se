var searchData=
[
  ['scores_351',['scores',['../d1/dee/saver_8c.html#a859dd84beee150c7f6f6e683f1dc91ac',1,'saver.c']]],
  ['state_352',['state',['../dc/d68/structkey__state.html#a42be32cf0cb8d287f43befbbb6715472',1,'key_state']]]
];
