var searchData=
[
  ['zero_232',['zero',['../d1/dee/saver_8c.html#a627f44b64b5d8d3ae8cb6a675f164405',1,'saver.c']]]
];
