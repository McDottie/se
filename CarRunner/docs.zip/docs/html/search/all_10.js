var searchData=
[
  ['r_175',['R',['../db/dc4/group__BUTTONS.html#ga5c71a5e59a53413cd6c270266d63b031',1,'CarRunner.h']]],
  ['readnames_176',['readNames',['../d5/d04/saver_8h.html#a66bcbb74da6580309611caac3a022592',1,'readNames(char *strings[]):&#160;saver.c'],['../d1/dee/saver_8c.html#a66bcbb74da6580309611caac3a022592',1,'readNames(char *strings[]):&#160;saver.c']]],
  ['readregister_177',['readRegister',['../d4/ddb/ADXL345_8c.html#a0e11c845302c3c61651b273be2fd0cf9',1,'ADXL345.c']]],
  ['readregisters_178',['readRegisters',['../d4/ddb/ADXL345_8c.html#a928ab41b39807da5e3cb8f495e99586c',1,'ADXL345.c']]],
  ['readscores_179',['readScores',['../d5/d04/saver_8h.html#a2970ebb257cd1fd2595b817dd35fe21b',1,'readScores():&#160;saver.c'],['../d1/dee/saver_8c.html#a2970ebb257cd1fd2595b817dd35fe21b',1,'readScores():&#160;saver.c']]],
  ['released_180',['RELEASED',['../d7/d0e/button_8h.html#ad74b7f5218b46c8332cd531df7178d45',1,'button.h']]],
  ['repeated_181',['REPEATED',['../d7/d0e/button_8h.html#ab75389a8a36ba24ff75c7bd7f47cfc09',1,'button.h']]],
  ['resetisr_182',['ResetISR',['../df/d04/cr__startup__lpc175x__6x_8c.html#a516ff8924be921fa3a1bb7754b1f5734',1,'cr_startup_lpc175x_6x.c']]],
  ['routinechooser_183',['routineChooser',['../de/d08/CarRunner_8c.html#a18e3ef9037a022b853f82460dc9fb422',1,'CarRunner.c']]],
  ['rs_184',['RS',['../da/def/lcd_8c.html#af8903d8eea3868940c60af887473b152',1,'lcd.c']]],
  ['rtc_2ec_185',['rtc.c',['../d4/dcc/rtc_8c.html',1,'']]],
  ['rtc_2eh_186',['rtc.h',['../dc/d1b/rtc_8h.html',1,'']]],
  ['rtc_5fgetseconds_187',['RTC_GetSeconds',['../dc/d1b/rtc_8h.html#aed5e5912abe16282e6934f5c108f4ca9',1,'RTC_GetSeconds(void):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#aed5e5912abe16282e6934f5c108f4ca9',1,'RTC_GetSeconds(void):&#160;rtc.c']]],
  ['rtc_5fgetvalue_188',['RTC_GetValue',['../dc/d1b/rtc_8h.html#a506e5d1d8d538575e4739d85f4db7ff1',1,'RTC_GetValue(struct tm *dateTime):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#a506e5d1d8d538575e4739d85f4db7ff1',1,'RTC_GetValue(struct tm *dateTime):&#160;rtc.c']]],
  ['rtc_5finit_189',['RTC_Init',['../dc/d1b/rtc_8h.html#a8ce39fc6eece59a57c6343c3ee52cbf5',1,'RTC_Init(time_t seconds):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#a8ce39fc6eece59a57c6343c3ee52cbf5',1,'RTC_Init(time_t seconds):&#160;rtc.c']]],
  ['rtc_5fsetseconds_190',['RTC_SetSeconds',['../dc/d1b/rtc_8h.html#acefa177b35b24cdd98a156950f7d051b',1,'RTC_SetSeconds(time_t seconds):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#acefa177b35b24cdd98a156950f7d051b',1,'RTC_SetSeconds(time_t seconds):&#160;rtc.c']]],
  ['rtc_5fsetvalue_191',['RTC_SetValue',['../dc/d1b/rtc_8h.html#a14fa105430d9febf19fe275cee4664d8',1,'RTC_SetValue(struct tm *dateTime):&#160;rtc.c'],['../d4/dcc/rtc_8c.html#a14fa105430d9febf19fe275cee4664d8',1,'RTC_SetValue(struct tm *dateTime):&#160;rtc.c']]]
];
