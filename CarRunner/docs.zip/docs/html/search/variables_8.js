var searchData=
[
  ['points_349',['points',['../d1/dcb/game_8c.html#af7f8f4a4e39e09fdb5e9f02330ecabef',1,'game.c']]],
  ['probabilitytospawn_350',['probabilityToSpawn',['../d1/dcb/game_8c.html#a8a57b46bc85e48c14b542545ffe17e0f',1,'game.c']]]
];
