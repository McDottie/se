var searchData=
[
  ['update_5fdatetimedisplay_214',['update_DateTimeDisplay',['../d7/dba/time__helper_8h.html#a958e6faf695f5b2090ca49efb5312446',1,'update_DateTimeDisplay(struct tm datetime):&#160;time_helper.c'],['../d3/d36/time__helper_8c.html#a308e0bb0c3298a97422fb39a878c11e5',1,'update_DateTimeDisplay(struct tm dateTime):&#160;time_helper.c']]],
  ['updategamedesign_215',['updateGameDesign',['../d1/dcb/game_8c.html#ac517e3bd03587b0c6cfcdb72a57a1ccf',1,'game.c']]],
  ['updategamelogic_216',['updateGameLogic',['../d1/dcb/game_8c.html#a9750389b435950c569d46a81cc21caca',1,'game.c']]],
  ['uproad_217',['upRoad',['../d1/dcb/game_8c.html#a93b50c6364a276c0d433111860c5ed97',1,'game.c']]],
  ['usagefault_5fhandler_218',['UsageFault_Handler',['../df/d04/cr__startup__lpc175x__6x_8c.html#a5fad9d61e19fbc1f3d3e53fbe0082c83',1,'cr_startup_lpc175x_6x.c']]]
];
