var searchData=
[
  ['checkclean_270',['checkClean',['../d1/dee/saver_8c.html#a4ae339342810f583b863eb857cabbc43',1,'saver.c']]]
];
