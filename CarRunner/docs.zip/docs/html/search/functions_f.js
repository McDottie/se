var searchData=
[
  ['time_5fchangeroutine_325',['Time_changeRoutine',['../d7/dba/time__helper_8h.html#a3d09c604a329253d63a4053e10edbbba',1,'Time_changeRoutine(time_t seconds):&#160;time_helper.c'],['../d3/d36/time__helper_8c.html#a3d09c604a329253d63a4053e10edbbba',1,'Time_changeRoutine(time_t seconds):&#160;time_helper.c']]]
];
