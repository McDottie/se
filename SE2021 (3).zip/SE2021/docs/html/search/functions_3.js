var searchData=
[
  ['wait_5fchronous_50',['WAIT_ChronoUs',['../df/d7c/group__WAIT__Public__Functions.html#ga1c152ed7920e9c4118a0cad2d776e816',1,'WAIT_ChronoUs(uint32_t waitUs):&#160;wait.c'],['../df/d7c/group__WAIT__Public__Functions.html#ga1c152ed7920e9c4118a0cad2d776e816',1,'WAIT_ChronoUs(uint32_t waitUs):&#160;wait.c']]],
  ['wait_5fgetelapsedmillis_51',['WAIT_GetElapsedMillis',['../df/d7c/group__WAIT__Public__Functions.html#ga704472853537ff855081d868bf2460a4',1,'WAIT_GetElapsedMillis(uint32_t start):&#160;wait.c'],['../df/d7c/group__WAIT__Public__Functions.html#ga704472853537ff855081d868bf2460a4',1,'WAIT_GetElapsedMillis(uint32_t start):&#160;wait.c']]],
  ['wait_5finit_52',['WAIT_Init',['../df/d7c/group__WAIT__Public__Functions.html#gaaf04f7010b8ca45e1053834d176b04f2',1,'WAIT_Init(void):&#160;wait.c'],['../df/d7c/group__WAIT__Public__Functions.html#gaaf04f7010b8ca45e1053834d176b04f2',1,'WAIT_Init(void):&#160;wait.c']]],
  ['wait_5fmilliseconds_53',['WAIT_Milliseconds',['../df/d7c/group__WAIT__Public__Functions.html#ga8d3111b31ffb9bce9b32370b46ae00fb',1,'WAIT_Milliseconds(uint32_t millis):&#160;wait.c'],['../df/d7c/group__WAIT__Public__Functions.html#ga8d3111b31ffb9bce9b32370b46ae00fb',1,'WAIT_Milliseconds(uint32_t millis):&#160;wait.c']]]
];
